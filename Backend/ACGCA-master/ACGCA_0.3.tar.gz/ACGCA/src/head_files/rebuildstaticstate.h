#ifndef REBUILDSTATICSTATE_H
#define REBUILDSTATICSTATE_H

#include "misc_growth_funcs.h"

extern void rebuildstaticstate(sparms *p, tstates *st,  gparms *gp, rebuild *rebld, int i, double deltaw);

#endif
